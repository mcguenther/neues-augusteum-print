Gebäude (Fuß-Fase 4,0, Schacht +0,35) und Kassetten (Spiel im Schacht 0,13, Buchsentasche 0,10 enger und 0,20 flacher) der Steckplatte 1:1300, Stand 19.10.2026.
Alle STL dicht, keine Kollision Kassette/Gebäude, Gebäude untereinander kollisionsfrei. Kassetten ohne LED-Streifen, Lage wie gedruckt (Tasche unten).
Die Kassetten sind der ungetestete Stand K5; die drei v4-Kassetten (Paulinum, Neues Augusteum, Hörsaalgebäude) sind identisch.
