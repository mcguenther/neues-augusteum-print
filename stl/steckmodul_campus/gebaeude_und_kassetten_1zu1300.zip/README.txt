Gebäude und Kassetten der Steckplatte 1:1300, Stand 20.10.2026 (neue Lage der Kassette im Neuen Augusteum, Fuß-Fase aus main, Berührkanten getrennt).
gebaeude/         die sechs Gebäude im Standardgewölbe (dicht, Berührkanten 0, keine Kollision mit der Kassette, untereinander kollisionsfrei)
gebaeude_offen/   Neues Augusteum mit offenem Gewölbe und Spaltenfix (16,34 statt 27,93 cm³; ungedruckt, dünne Wände bis 36 mm frei, 64 Dreiecke mit Fläche null)
kassetten/        Kassetten im Stand K5 (Spiel im Schacht 0,13, Buchsentasche 0,10 enger und 0,20 flacher), ohne LED-Streifen; die drei v4-Kassetten sind identisch
Die Steckplatte dazu liegt in druckdaten_campus_1zu1300.zip (Platte, Hof-Einsatz, Gebäude, Prüfbericht).
